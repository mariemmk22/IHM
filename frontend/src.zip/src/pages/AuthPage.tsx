import { useState } from "react";
import { motion } from "framer-motion";
import {
  Eye,
  EyeOff,
  Mail,
  Lock,
  User,
  Phone,
  MapPin,
  ArrowLeft,
  Briefcase,
  Home,
} from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useSearchParams, Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  login as apiLogin,
  registerClient as apiRegisterClient,
  AuthResponse,
  LoginParams,
  RegisterClientParams,
} from "@/lib/authApi";
import heroBg from "@/assets/hero-bg.jpg";

const regions = [
  "Tunis", "Ariana", "Ben Arous", "Manouba", "Nabeul", "Zaghouan",
  "Bizerte", "Béja", "Jendouba", "Kef", "Siliana", "Sousse",
  "Monastir", "Mahdia", "Sfax", "Kairouan", "Kasserine", "Sidi Bouzid",
  "Gabès", "Médenine", "Tataouine", "Gafsa", "Tozeur", "Kébili",
];

export default function AuthPage() {
  const [searchParams] = useSearchParams();
  const defaultTab = searchParams.get("tab") === "register" ? "register" : "login";
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  const { login } = useAuth();

  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");

  const [form, setForm] = useState({
    nom: "",
    prenom: "",
    email: "",
    telephone: "",
    password: "",
    region: "",
  });

  const loginMutation = useMutation<AuthResponse, Error, LoginParams>({
    mutationFn: apiLogin,
    onSuccess: (data) => {
      login(data.user, data.token);
      toast.success(data.message || "Connexion réussie !");
      navigate("/");
    },
    onError: (error) => {
      toast.error(error.message || "Erreur de connexion");
    },
  });

  const registerMutation = useMutation<AuthResponse, Error, RegisterClientParams>({
    mutationFn: apiRegisterClient,
    onSuccess: (data) => {
      login(data.user, data.token);
      toast.success(data.message || "Inscription réussie !");
      navigate("/");
    },
    onError: (error) => {
      toast.error(error.message || "Erreur lors de l'inscription");
    },
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail || !loginPassword) {
      toast.error("Veuillez remplir tous les champs");
      return;
    }
    loginMutation.mutate({ email: loginEmail, motDePasse: loginPassword });
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nom || !form.prenom || !form.email || !form.password || !form.telephone) {
      toast.error("Veuillez remplir tous les champs obligatoires");
      return;
    }
    registerMutation.mutate({
      nom: form.nom,
      prenom: form.prenom,
      email: form.email,
      motDePasse: form.password,
      telephone: form.telephone,
      region: form.region || undefined,
      adresse: undefined,
    });
  };

  const updateForm = (key: string, value: string) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  return (
    <div className="min-h-screen bg-[#f6f8fb] flex flex-col">
      {/* Navbar Professionnelle */}
      <header className="fixed top-0 left-0 right-0 z-50 border-b border-slate-200/80 bg-white/92 backdrop-blur-xl shadow-[0_6px_24px_-18px_rgba(15,23,42,0.18)]">
        <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6 lg:px-12">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-blue-500 text-white shadow-md transition-transform group-hover:scale-105">
              <Briefcase className="h-5 w-5" />
            </div>
            <div className="leading-tight">
              <p className="text-lg font-bold tracking-tight text-slate-900">ServiDom</p>
              <p className="text-xs font-medium text-slate-500">Services à domicile</p>
            </div>
          </Link>

          <nav className="flex items-center">
            {/* Bouton Home Icon Professionnel et Visible */}
            
          </nav>
        </div>
      </header>

      {/* Contenu principal */}
      <main className="mx-auto w-full max-w-7xl flex-1 grid lg:grid-cols-2 gap-0 pt-20">
        
        {/* Partie gauche - Texte amélioré */}
        <div className="hidden lg:flex items-center justify-start px-6 lg:px-12 py-8">
          <div className="relative h-full w-full max-h-[80vh] overflow-hidden rounded-[2.5rem] shadow-[0_30px_80px_-30px_rgba(15,23,42,0.35)]">
            <img
              src={heroBg}
              alt="Services à domicile"
              className="h-full w-full object-cover object-[54%_center] scale-[1.04]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />

            <div className="absolute bottom-12 left-12 right-12 z-10">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <h1 className="mb-4 text-4xl font-black leading-tight text-white xl:text-5xl">
                  La solution pour vos <br />
                  <span className="text-blue-400">besoins quotidiens.</span>
                </h1>
                <p className="max-w-md text-lg font-medium leading-8 text-slate-200">
                  Rejoignez la plus grande communauté de prestataires de services
                  en Tunisie. <span className="text-white font-bold">Simple, rapide et sécurisé.</span>
                </p>
              </motion.div>
            </div>
          </div>
        </div>

        {/* Partie droite - Formulaire */}
        <div className="flex items-center justify-center p-6 lg:p-12">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="w-full max-w-[440px]"
          >
            <Tabs defaultValue={defaultTab} className="w-full">
              <TabsList className="mb-8 grid h-14 w-full grid-cols-2 rounded-2xl border border-slate-200/80 bg-white/80 p-1.5 shadow-sm">
                <TabsTrigger value="login" className="rounded-xl text-sm font-bold">Connexion</TabsTrigger>
                <TabsTrigger value="register" className="rounded-xl text-sm font-bold">Inscription</TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <Card className="rounded-[2rem] border border-white/60 bg-white/80 shadow-xl backdrop-blur-sm">
                  <CardContent className="p-8">
                    <form onSubmit={handleLogin} className="space-y-5">
                      <div className="space-y-2">
                        <Label className="ml-1 text-sm font-semibold text-slate-800">Email professionnel</Label>
                        <div className="relative">
                          <Mail className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                          <Input
                            type="email"
                            placeholder="nom@exemple.com"
                            className="h-13 rounded-2xl pl-12 focus-visible:ring-blue-500"
                            value={loginEmail}
                            onChange={(e) => setLoginEmail(e.target.value)}
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center justify-between px-1">
                          <Label className="text-sm font-semibold text-slate-800">Mot de passe</Label>
                          <a href="#" className="text-xs font-bold text-blue-600 hover:underline">Oublié ?</a>
                        </div>
                        <div className="relative">
                          <Lock className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                          <Input
                            type={showPassword ? "text" : "password"}
                            className="h-13 rounded-2xl pl-12 pr-12 focus-visible:ring-blue-500"
                            value={loginPassword}
                            onChange={(e) => setLoginPassword(e.target.value)}
                            required
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400"
                          >
                            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                      </div>

                      <Button type="submit" className="h-13 w-full rounded-2xl bg-blue-600 font-bold text-white shadow-lg transition-transform active:scale-[0.98] hover:bg-blue-700">
                        Se connecter
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="register">
                <Card className="rounded-[2rem] border border-white/60 bg-white/80 shadow-xl backdrop-blur-sm">
                  <CardContent className="max-h-[60vh] overflow-y-auto p-8 custom-scrollbar">
                    <form onSubmit={handleRegister} className="space-y-5">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="text-xs font-bold uppercase text-slate-500">Nom</Label>
                          <Input className="h-12 rounded-xl focus-visible:ring-blue-500" value={form.nom} onChange={(e) => updateForm("nom", e.target.value)} required />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-xs font-bold uppercase text-slate-500">Prénom</Label>
                          <Input className="h-12 rounded-xl focus-visible:ring-blue-500" value={form.prenom} onChange={(e) => updateForm("prenom", e.target.value)} required />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-sm font-semibold text-slate-800">Email</Label>
                        <Input type="email" className="h-12 rounded-xl focus-visible:ring-blue-500" value={form.email} onChange={(e) => updateForm("email", e.target.value)} required />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-sm font-semibold text-slate-800">Téléphone</Label>
                        <Input type="tel" className="h-12 rounded-xl focus-visible:ring-blue-500" value={form.telephone} onChange={(e) => updateForm("telephone", e.target.value)} required />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-sm font-semibold text-slate-800">Région</Label>
                        <Select onValueChange={(v) => updateForm("region", v)}>
                          <SelectTrigger className="h-12 rounded-xl border-slate-200 focus:ring-blue-500">
                            <SelectValue placeholder="Choisir une ville" />
                          </SelectTrigger>
                          <SelectContent className="rounded-xl border-slate-200 shadow-xl">
                            {regions.map((r) => (
                              <SelectItem 
                                key={r} 
                                value={r}
                                // Suppression du vert : On utilise un bleu doux pour le focus (survol/sélection)
                                className="focus:bg-blue-50 focus:text-blue-700 cursor-pointer transition-colors"
                              >
                                {r}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-sm font-semibold text-slate-800">Mot de passe</Label>
                        <Input type="password" className="h-12 rounded-xl focus-visible:ring-blue-500" value={form.password} onChange={(e) => updateForm("password", e.target.value)} required />
                      </div>
                      <Button type="submit" className="h-13 w-full rounded-2xl bg-blue-600 font-bold text-white shadow-lg hover:bg-blue-700">
                        Créer mon compte
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </motion.div>
        </div>
      </main>
    </div>
  );
}