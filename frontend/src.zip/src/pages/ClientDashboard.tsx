import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import {
  User, Calendar, Star, MapPin, LogOut, Home, Heart,
  Clock, ChevronRight, Settings, Bell, BarChart3, Menu, X,
  Heart as HeartIcon, Award, TrendingUp, MessageSquare, Briefcase
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/context/AuthContext";
import { useClientDashboard } from "@/hooks/useClientDashboard";
import { createAvis, getMyAvis, type ClientAvisDto } from "@/lib/avisApi";
import { getClientRendezVous, type ClientRendezVousDto } from "@/lib/rendezVousApi";
import { type DashboardAppointmentDto } from "@/lib/dashboardApi";
import { toast } from "sonner";

interface ClientUser {
  id?: string;
  prenom?: string;
  nom?: string;
  email?: string;
  telephone?: string;
  region?: string;
  specialite?: string;
  description?: string;
}

interface ReviewFormState {
  rendezVousId: string;
  rating: number;
  comment: string;
}

interface DashboardData {
  appointmentCount: number;
  favoriteCount: number;
  reviewCount: number;
  pendingAppointments: number;
  recentAppointments: DashboardAppointmentDto[];
}

const statusColors = {
  en_attente: "bg-warning/10 text-warning",
  accepte: "bg-success/10 text-success",
  annule: "bg-destructive/10 text-destructive",
};

const statusLabels = {
  en_attente: "En attente",
  accepte: "Accepté",
  annule: "Annulé",
};

function formatAppointmentDate(dateValue: string) {
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(dateValue);
  const date = match ? new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3])) : new Date(dateValue);

  if (Number.isNaN(date.getTime())) {
    return dateValue;
  }

  return new Intl.DateTimeFormat("fr-FR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  }).format(date);
}

function Badge({ children, color = "#6366f1" }: { children: React.ReactNode; color?: string }) {
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold"
      style={{ background: `${color}18`, color }}
    >
      {children}
    </span>
  );
}

function Avatar({
  initials,
  size = "md",
  gradient = false,
}: {
  initials: string;
  size?: "sm" | "md" | "lg" | "xl";
  gradient?: boolean;
}) {
  const sizes = { sm: "w-8 h-8 text-xs", md: "w-10 h-10 text-sm", lg: "w-14 h-14 text-base", xl: "w-24 h-24 text-2xl" };
  return (
    <div
      className={`${sizes[size]} rounded-2xl flex items-center justify-center font-bold flex-shrink-0`}
      style={
        gradient
          ? { background: "linear-gradient(135deg, #6366f1 0%, #8b5cf6 50%, #a78bfa 100%)" }
          : { background: "linear-gradient(135deg, #e0e7ff 0%, #c7d2fe 100%)", color: "#4f46e5" }
      }
    >
      <span className={gradient ? "text-white" : ""}>{initials}</span>
    </div>
  );
}

const TABS = [
  { id: "overview", label: "Vue d'ensemble", icon: BarChart3 },
  { id: "appointments", label: "Rendez-vous", icon: Calendar },
  { id: "myreviews", label: "Mes avis", icon: Star },
  { id: "newreview", label: "Déposer un avis", icon: MessageSquare },
  { id: "profile", label: "Mon profil", icon: User },
  { id: "settings", label: "Paramètres", icon: Settings },
];

export default function ClientDashboard() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const dashboardQuery = useClientDashboard(user?.id ?? undefined);
  const dashboardData = dashboardQuery.data as DashboardData | undefined;
  const appointmentsQuery = useQuery<ClientRendezVousDto[], Error>({
    queryKey: ["rendez-vous", "client", user?.id],
    queryFn: () => getClientRendezVous(user?.id ?? ""),
    enabled: Boolean(user?.id),
  });
  const clientAppointments = (appointmentsQuery.data ?? 
    (dashboardData?.recentAppointments as ClientRendezVousDto[] | undefined) ?? 
    []) as ClientRendezVousDto[];

  const { data: clientAvis = [] } = useQuery<ClientAvisDto[], Error>({
    queryKey: ["avis", "me"],
    queryFn: () => getMyAvis(),
    enabled: Boolean(user?.id),
  });

  const [activeTab, setActiveTab] = useState("overview");
  const [reviewForm, setReviewForm] = useState<ReviewFormState>({ rendezVousId: "", rating: 5, comment: "" });
  const [isMobile, setIsMobile] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const displayName = user?.prenom?.trim() || user?.nom?.trim() || "Client";
  const initials = `${user?.prenom?.[0] ?? ""}${user?.nom?.[0] ?? ""}`.trim() || "CL";

  const reviewMutation = useMutation({
    mutationFn: async () => {
      if (!reviewForm.rendezVousId) {
        throw new Error("Sélectionnez un rendez-vous accepté");
      }

      return createAvis({
        rendezVousId: reviewForm.rendezVousId,
        nbstart: reviewForm.rating,
        comment: reviewForm.comment,
      });
    },
    onSuccess: () => {
      toast.success("Avis envoyé avec succès");
      setReviewForm({ rendezVousId: "", rating: 5, comment: "" });
      queryClient.invalidateQueries({ queryKey: ["dashboard", "client", user?.id] });
      queryClient.invalidateQueries({ queryKey: ["rendez-vous", "client", user?.id] });
      queryClient.invalidateQueries({ queryKey: ["avis", "me"] });
    },
    onError: (error: Error) => {
      toast.error(error.message || "Impossible d'envoyer l'avis");
    },
  });

  const acceptedAppointments = clientAppointments.filter((apt) => apt.statut === "accepte");

  useEffect(() => {
    const checkScreen = () => {
      const mobile = window.innerWidth < 1024;
      setIsMobile(mobile);
      setSidebarOpen(!mobile);
    };

    checkScreen();
    window.addEventListener("resize", checkScreen);
    return () => window.removeEventListener("resize", checkScreen);
  }, []);

  return (
    <div
      style={{
        fontFamily: "'Plus Jakarta Sans', 'DM Sans', system-ui, sans-serif",
        background: "linear-gradient(135deg, #f8f7ff 0%, #f0f4ff 50%, #fdf2f8 100%)",
        color: "#1e1b4b",
        display: "flex",
        flexDirection: "column",
        minHeight: "100vh",
      }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html, body, #root { width: 100%; max-width: 100%; overflow-x: hidden; }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #c7d2fe; border-radius: 4px; }
         .glass {
    background: rgba(255,255,255,0.78);
    backdrop-filter: blur(18px);
    -webkit-backdrop-filter: blur(18px);
    border: 1px solid rgba(255,255,255,0.88);
  }

  .card {
    background: rgba(255,255,255,0.84);
    backdrop-filter: blur(16px);
    border: 1px solid rgba(255,255,255,0.92);
    border-radius: 20px;
    box-shadow: 0 4px 24px rgba(99,102,241,0.07), 0 1px 4px rgba(0,0,0,0.04);
    min-width: 0;
  }

  .stat-card {
    background: white;
    border-radius: 20px;
    box-shadow: 0 2px 16px rgba(99,102,241,0.08);
    border: 1px solid rgba(99,102,241,0.08);
    transition: transform 0.2s, box-shadow 0.2s;
    min-width: 0;
  }

  .stat-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 32px rgba(99,102,241,0.14);
  }

  .sidebar-shell {
    background: rgba(255,255,255,0.88);
    backdrop-filter: blur(18px);
    -webkit-backdrop-filter: blur(18px);
    border-right: 1px solid rgba(99,102,241,0.08);
    box-shadow: 2px 0 20px rgba(99,102,241,0.05);
  }

  .sidebar-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    border-radius: 14px;
    cursor: pointer;
    transition: all 0.18s ease;
    font-size: 14px;
    font-weight: 500;
    color: #6b7280;
    min-height: 46px;
    border: none;
    width: 100%;
    background: transparent;
    text-align: left;
  }

  .sidebar-item:hover {
    background: rgba(99,102,241,0.08);
    color: #4f46e5;
  }

  .sidebar-item.active {
    background: linear-gradient(135deg, #6366f1 0%, #818cf8 100%);
    color: white;
    box-shadow: 0 4px 16px rgba(99,102,241,0.28);
  }

  .btn-primary {
    background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
    color: white;
    border: none;
    border-radius: 12px;
    padding: 10px 20px;
    font-weight: 600;
    font-size: 14px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all 0.2s;
    box-shadow: 0 4px 14px rgba(99,102,241,0.3);
    white-space: nowrap;
  }

  .btn-primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 6px 20px rgba(99,102,241,0.4);
  }

  .input-field {
    width: 100%;
    padding: 12px 16px;
    border-radius: 12px;
    border: 1.5px solid #e0e7ff;
    background: #fafafe;
    font-size: 14px;
    outline: none;
    transition: border-color 0.2s, box-shadow 0.2s;
    font-family: inherit;
    color: #1e1b4b;
  }

  .input-field:focus {
    border-color: #6366f1;
    box-shadow: 0 0 0 3px rgba(99,102,241,0.12);
  }

  .dashboard-main {
    flex: 1;
    min-width: 0;
    width: 100%;
    overflow: auto;
    display: flex;
    flex-direction: column;
  }

  @media (min-width: 1024px) {
    .dashboard-main {
      margin-left: 0;
    }
  }

  @media (max-width: 1024px) {
    .stat-card { border-radius: 18px; }
  }

  @media (max-width: 768px) {
    .card, .stat-card { border-radius: 16px; }
    .btn-primary { padding: 9px 14px; font-size: 13px; }
    .sidebar-item { padding: 12px 14px; }
  }

        .glass {
          background: rgba(255,255,255,0.72);
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          border: 1px solid rgba(255,255,255,0.85);
        }
        .card {
          background: rgba(255,255,255,0.82);
          backdrop-filter: blur(16px);
          border: 1px solid rgba(255,255,255,0.9);
          border-radius: 20px;
          box-shadow: 0 4px 24px rgba(99,102,241,0.07), 0 1px 4px rgba(0,0,0,0.04);
          min-width: 0;
        }
        .stat-card {
          background: white;
          border-radius: 20px;
          box-shadow: 0 2px 16px rgba(99,102,241,0.08);
          border: 1px solid rgba(99,102,241,0.08);
          transition: transform 0.2s, box-shadow 0.2s;
          min-width: 0;
        }
        .stat-card:hover { transform: translateY(-3px); box-shadow: 0 8px 32px rgba(99,102,241,0.14); }
        .sidebar-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 11px 16px;
          border-radius: 14px;
          cursor: pointer;
          transition: all 0.18s;
          font-size: 14px;
          font-weight: 500;
          color: #6b7280;
          min-height: 46px;
        }
        .sidebar-item:hover { background: rgba(99,102,241,0.08); color: #4f46e5; }
        .sidebar-item.active {
          background: linear-gradient(135deg, #6366f1 0%, #818cf8 100%);
          color: white;
          box-shadow: 0 4px 16px rgba(99,102,241,0.3);
        }
        .btn-primary {
          background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
          color: white;
          border: none;
          border-radius: 12px;
          padding: 10px 20px;
          font-weight: 600;
          font-size: 14px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          transition: all 0.2s;
          box-shadow: 0 4px 14px rgba(99,102,241,0.3);
          white-space: nowrap;
        }
        .btn-primary:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(99,102,241,0.4); }
        .input-field {
          width: 100%;
          padding: 12px 16px;
          border-radius: 12px;
          border: 1.5px solid #e0e7ff;
          background: #fafafe;
          font-size: 14px;
          outline: none;
          transition: border-color 0.2s, box-shadow 0.2s;
          font-family: inherit;
          color: #1e1b4b;
        }
        .input-field:focus { border-color: #6366f1; box-shadow: 0 0 0 3px rgba(99,102,241,0.12); }
        @media (max-width: 1024px) {
          .stat-card { border-radius: 18px; }
        }
        @media (max-width: 768px) {
          .card, .stat-card { border-radius: 16px; }
          .btn-primary { padding: 9px 14px; font-size: 13px; }
          .sidebar-item { padding: 12px 14px; }
        }
      `}</style>

      <Navbar />

      <div
        style={{
          display: "flex",
          flex: 1,
          position: "relative",
          minWidth: 0,
          width: "100%",
        }}
      >
        <AnimatePresence>
          {isMobile && sidebarOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSidebarOpen(false)}
              style={{
                position: "fixed",
                inset: 0,
                background: "rgba(15, 23, 42, 0.35)",
                zIndex: 60,
              }}
            />
          )}
        </AnimatePresence>
<AnimatePresence>
  {isMobile && sidebarOpen && (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={() => setSidebarOpen(false)}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(15, 23, 42, 0.35)",
        zIndex: 60,
      }}
    />
  )}
</AnimatePresence>

<AnimatePresence mode="wait">
  {(!isMobile || sidebarOpen) && (
    <motion.aside
      initial={isMobile ? { x: -320, opacity: 0 } : false}
      animate={
        isMobile
          ? { x: 0, opacity: 1 }
          : { x: 0, opacity: 1 }
      }
      exit={isMobile ? { x: -320, opacity: 0 } : undefined}
      transition={{ duration: 0.28, ease: "easeInOut" }}
      className="sidebar-shell"
      style={{
        position: isMobile ? "fixed" : "sticky",
        top: isMobile ? 0 : 0,
        left: 0,
        width: 270,
        minWidth: 270,
        height: isMobile ? "100vh" : "calc(100vh - 64px)",
        marginTop: isMobile ? 0 : 0,
        zIndex: isMobile ? 70 : 20,
        display: "flex",
        flexDirection: "column",
        padding: "18px 16px",
        overflowY: "auto",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          marginBottom: 24,
          paddingInline: 8,
        }}
      >
  
        {isMobile && (
          <button
            onClick={() => setSidebarOpen(false)}
            style={{
              width: 36,
              height: 36,
              borderRadius: 10,
              border: "1px solid #e5e7eb",
              background: "white",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: "#6366f1",
            }}
          >
            <X size={18} />
          </button>
        )}
      </div>

      <nav style={{ display: "flex", flexDirection: "column", gap: 6, flex: 1 }}>
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              setActiveTab(tab.id);
              if (isMobile) setSidebarOpen(false);
            }}
            className={`sidebar-item ${activeTab === tab.id ? "active" : ""}`}
          >
            <tab.icon size={18} style={{ flexShrink: 0 }} />
            <span>{tab.label}</span>
          </button>
        ))}
      </nav>

      <button
        style={{
          display: "flex",
          alignItems: "center",
          gap: 12,
          padding: "12px 16px",
          borderRadius: 14,
          border: "none",
          background: "transparent",
          cursor: "pointer",
          fontSize: 14,
          fontWeight: 500,
          color: "#6b7280",
          transition: "all 0.18s ease",
          width: "100%",
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = "rgba(255, 67, 54, 0.08)";
          e.currentTarget.style.color = "#ef4444";
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = "transparent";
          e.currentTarget.style.color = "#6b7280";
        }}
      >
        <LogOut size={18} />
        <span>Déconnexion</span>
      </button>
    </motion.aside>
  )}
</AnimatePresence>

        <main
         className="dashboard-main"
        >
       <div
  className="glass"
  style={{
    position: "sticky",
    top: 0,
    zIndex: 40,
    minHeight: 64,
    width: "100%",
    borderBottom: "1px solid rgba(99,102,241,0.1)",
    padding: isMobile ? "0 16px" : "0 24px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 16,
  }}
>
            <div>
              <div style={{ fontWeight: 700, fontSize: 16, color: "#1e1b4b" }}>Bonjour, {displayName} 👋</div>
              <div style={{ fontSize: 12, color: "#9ca3af", marginTop: 2 }}>Bienvenue sur votre espace client</div>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                style={{
                  display: isMobile ? "flex" : "none",
                  alignItems: "center",
                  justifyContent: "center",
                  width: 40,
                  height: 40,
                  borderRadius: 10,
                  border: "none",
                  background: "transparent",
                  cursor: "pointer",
                  color: "#6366f1",
                }}
              >
                {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
              <Avatar initials={initials} size="md" />
            </div>
          </div>

          <div
            style={{
              flex: 1,
              padding: isMobile ? "16px" : "28px",
              minWidth: 0,
            }}
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.25, ease: "easeOut" }}
              >
                {activeTab === "overview" && <OverviewTab dashboard={dashboardData} isLoading={dashboardQuery.isLoading} appointments={clientAppointments} />}
                {activeTab === "appointments" && <AppointmentsTab appointments={clientAppointments} isMobile={isMobile} />}
                {activeTab === "myreviews" && <MyReviewsTab reviews={clientAvis} />}
                {activeTab === "newreview" && (
                  <NewReviewTab
                    acceptedAppointments={acceptedAppointments}
                    reviewForm={reviewForm}
                    setReviewForm={setReviewForm}
                    reviewMutation={reviewMutation}
                  />
                )}
                {activeTab === "profile" && (
                  <ProfileTab displayName={displayName} user={user} email={user?.email} phone={user?.telephone} region={user?.region} />
                )}
                {activeTab === "settings" && <SettingsTab />}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>
    </div>
  );
}

interface OverviewTabProps {
  dashboard?: DashboardData;
  isLoading: boolean;
  appointments: ClientRendezVousDto[];
}

interface AppointmentsTabProps {
  appointments: ClientRendezVousDto[];
  isMobile: boolean;
}

interface ProfileTabProps {
  displayName: string;
  user: ClientUser | null | undefined;
  email?: string;
  phone?: string;
  region?: string;
}

interface MyReviewsTabProps {
  reviews: ClientAvisDto[];
}

interface NewReviewTabProps {
  acceptedAppointments: ClientRendezVousDto[];
  reviewForm: ReviewFormState;
  setReviewForm: (value: ReviewFormState) => void;
  reviewMutation: {
    mutate: () => void;
    isPending: boolean;
  };
}

function OverviewTab({ dashboard, isLoading, appointments }: OverviewTabProps) {
  const stats = [
    { label: "Rendez-vous", value: dashboard?.appointmentCount ?? 0, icon: Calendar, color: "#6366f1" },
    { label: "Favoris", value: dashboard?.favoriteCount ?? 0, icon: HeartIcon, color: "#ec4899" },
    { label: "Avis donnés", value: dashboard?.reviewCount ?? 0, icon: Star, color: "#f59e0b" },
    { label: "En attente", value: dashboard?.pendingAppointments ?? 0, icon: Clock, color: "#10b981" },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24, minWidth: 0 }}>
      {isLoading && !dashboard ? (
        <div className="card" style={{ padding: 22 }}>Chargement du tableau de bord...</div>
      ) : null}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 16 }}>
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            className="stat-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.07 }}
            style={{ padding: "20px 22px" }}
          >
            <stat.icon size={20} color={stat.color} style={{ marginBottom: 12 }} />
            <div style={{ fontSize: 24, fontWeight: 700, color: "#1e1b4b", marginBottom: 4 }}>{stat.value}</div>
            <div style={{ fontSize: 12, color: "#9ca3af" }}>{stat.label}</div>
          </motion.div>
        ))}
      </div>

      <div className="card" style={{ padding: 22 }}>
        <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 16 }}>Mes rendez-vous à venir</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {appointments.filter(apt => apt.statut === "accepte").slice(0, 3).map((apt, i) => (
            <motion.div
              key={apt.id}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                paddingBottom: 10,
                borderBottom: i < 2 ? "1px solid rgba(99,102,241,0.1)" : "none",
              }}
            >
              <div>
                <div style={{ fontWeight: 600, fontSize: 13 }}>{apt.service?.nomService}</div>
                <div style={{ fontSize: 11, color: "#9ca3af", marginTop: 2 }}>{formatAppointmentDate(apt.dateRdv)}</div>
              </div>
              <Badge color="#10b981">Confirmé</Badge>
            </motion.div>
          ))}
          {appointments.filter(apt => apt.statut === "accepte").length === 0 && (
            <div style={{ fontSize: 12, color: "#9ca3af", textAlign: "center", padding: "18px 0" }}>Aucun rendez-vous confirmé</div>
          )}
        </div>
      </div>
    </div>
  );
}

function AppointmentsTab({ appointments, isMobile }: AppointmentsTabProps) {
  const [filter, setFilter] = useState("all");
  const filtered = filter === "all" ? appointments : appointments.filter((apt) => apt.statut === filter);

  return (
    <div style={{ width: "100%" }}>
      <div style={{ display: "flex", gap: 8, marginBottom: 22, flexWrap: "wrap" }}>
        {[
          { id: "all", label: "Tous" },
          { id: "accepte", label: "Acceptés" },
          { id: "en_attente", label: "En attente" },
          { id: "annule", label: "Annulés" },
        ].map((f) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            style={{
              padding: "8px 18px",
              borderRadius: 12,
              border: "1.5px solid",
              borderColor: filter === f.id ? "#6366f1" : "#e0e7ff",
              background: filter === f.id ? "#eef2ff" : "white",
              color: filter === f.id ? "#4f46e5" : "#6b7280",
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {filtered.length > 0 ? (
          filtered.map((apt, i) => (
            <motion.div
              key={apt.id}
              className="card"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              style={{ padding: "18px 22px" }}
            >
              <div style={{ display: "flex", alignItems: isMobile ? "flex-start" : "center", gap: 16, flexWrap: "wrap" }}>
                <Avatar initials={apt.service?.nomService?.[0]?.toUpperCase() ?? "RD"} size="md" />
                <div style={{ flex: 1, minWidth: 180 }}>
                  <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 3 }}>
                    {apt.service?.nomService ?? "Service"}
                  </div>
                  <div style={{ fontSize: 12, color: "#6b7280" }}>{apt.adresseIntervention}</div>
                </div>
                <div style={{ textAlign: "right", display: "flex", flexDirection: "column", alignItems: isMobile ? "flex-start" : "flex-end", gap: 4 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: "#6366f1", display: "flex", alignItems: "center", gap: 4 }}>
                    <Calendar size={11} /> {formatAppointmentDate(apt.dateRdv)} {apt.heureRdv ? `• ${apt.heureRdv}` : ""}
                  </div>
                  <Badge color={apt.statut === "accepte" ? "#10b981" : apt.statut === "en_attente" ? "#f59e0b" : "#ef4444"}>
                    {statusLabels[apt.statut as keyof typeof statusLabels]}
                  </Badge>
                </div>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="card" style={{ padding: 22, textAlign: "center", color: "#6b7280" }}>
            Aucun rendez-vous {filter !== "all" ? "dans cette catégorie" : "pour le moment"}.
          </div>
        )}
      </div>
    </div>
  );
}

function ProfileTab({ displayName, user, email, phone, region }: ProfileTabProps) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20, width: "100%", minWidth: 0 }}>
      <div className="card" style={{ padding: 22 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 20, marginBottom: 24, flexWrap: "wrap" }}>
          <Avatar initials={`${user?.prenom?.[0] ?? ""}${user?.nom?.[0] ?? ""}`} size="lg" gradient />
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 18, marginBottom: 4, color: "#1e1b4b" }}>{displayName}</div>
            <div style={{ fontSize: 13, color: "#6b7280", marginBottom: 12 }}>Client ServiDom</div>
            <div style={{ display: "flex", gap: 16, flexWrap: "wrap", fontSize: 12 }}>
              {email && <div style={{ color: "#6b7280" }}>📧 {email}</div>}
              {phone && <div style={{ color: "#6b7280" }}>📞 {phone}</div>}
              {region && <div style={{ color: "#6b7280" }}>📍 {region}</div>}
            </div>
          </div>
        </div>
        <p style={{ fontSize: 13, color: "#6b7280", lineHeight: 1.6 }}>
          Soyez assuré de bénéficier des meilleurs services. Explorez nos prestataires de confiance et réservez facilement vos rendez-vous.
        </p>
      </div>
    </div>
  );
}

function MyReviewsTab({ reviews }: MyReviewsTabProps) {
  return (
    <div style={{ width: "100%" }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        {reviews.length > 0 ? (
          reviews.map((review, i) => (
            <motion.div
              key={review.idAvis}
              className="card"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              style={{ padding: "18px 22px" }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12, gap: 12, flexWrap: "wrap" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <Avatar initials={review.prestataire ? `${review.prestataire.prenom?.[0] ?? ""}${review.prestataire.nom?.[0] ?? ""}`.trim() || "PR" : "PR"} size="md" />
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 2 }}>
                      {review.service?.nomService ?? "Service"}
                    </div>
                    <div style={{ fontSize: 12, color: "#6b7280" }}>
                      {review.prestataire ? `${review.prestataire.prenom} ${review.prestataire.nom}` : "Prestataire"}
                    </div>
                    <div style={{ fontSize: 11, color: "#9ca3af", marginTop: 2 }}>
                      {new Date(review.dateAvis).toLocaleDateString("fr-FR", { year: "numeric", month: "long", day: "numeric" })}
                    </div>
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      size={14}
                      color={i < review.rating ? "#f59e0b" : "#e0e7ff"}
                      fill={i < review.rating ? "#f59e0b" : "none"}
                    />
                  ))}
                </div>
              </div>
              {review.comment && (
                <p style={{ fontSize: 13, lineHeight: 1.6, color: "#4b5563", marginTop: 10 }}>
                  "{review.comment}"
                </p>
              )}
            </motion.div>
          ))
        ) : (
          <div className="card" style={{ padding: 22, textAlign: "center", color: "#6b7280" }}>
            <Star size={32} style={{ margin: "0 auto 12px", opacity: 0.3 }} />
            <p style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>Aucun avis donné</p>
            <p style={{ fontSize: 12 }}>Vous n'avez pas encore donné d'avis. Complétez un rendez-vous pour en laisser un.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function NewReviewTab({ acceptedAppointments, reviewForm, setReviewForm, reviewMutation }: NewReviewTabProps) {
  return (
    <div style={{ width: "100%" }}>
      <div className="card" style={{ padding: 22 }}>
        <h3 style={{ fontWeight: 700, fontSize: 15, marginBottom: 18, color: "#6366f1" }}>Déposer un avis</h3>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: "#6b7280", display: "block", marginBottom: 6 }}>Rendez-vous</label>
            <select
              className="input-field"
              value={reviewForm.rendezVousId}
              onChange={(event) => setReviewForm({ ...reviewForm, rendezVousId: event.target.value })}
            >
              <option value="">Choisir un rendez-vous accepté</option>
              {acceptedAppointments.map((apt) => (
                <option key={apt.id} value={apt.id}>
                  {apt.service?.nomService ?? "Service"} - {formatAppointmentDate(apt.dateRdv)}
                </option>
              ))}
            </select>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
            <div>
              <label style={{ fontSize: 12, fontWeight: 600, color: "#6b7280", display: "block", marginBottom: 6 }}>Note</label>
              <select
                className="input-field"
                value={reviewForm.rating}
                onChange={(event) => setReviewForm({ ...reviewForm, rating: Number(event.target.value) })}
              >
                {[5, 4, 3, 2, 1].map((value) => (
                  <option key={value} value={value}>{value} / 5</option>
                ))}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 12, fontWeight: 600, color: "#6b7280", display: "block", marginBottom: 6 }}>★★★★★</label>
              <div style={{ display: "flex", gap: 4, alignItems: "center", height: 44 }}>
                {[1, 2, 3, 4, 5].map((i) => (
                  <Star
                    key={i}
                    size={20}
                    color={i <= reviewForm.rating ? "#f59e0b" : "#e0e7ff"}
                    fill={i <= reviewForm.rating ? "#f59e0b" : "none"}
                  />
                ))}
              </div>
            </div>
          </div>

          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: "#6b7280", display: "block", marginBottom: 6 }}>Votre avis</label>
            <textarea
              className="input-field"
              placeholder="Partagez votre expérience..."
              value={reviewForm.comment}
              onChange={(event) => setReviewForm({ ...reviewForm, comment: event.target.value })}
              style={{ minHeight: 120, padding: "12px 16px", fontFamily: "inherit" }}
            />
          </div>

          <button
            className="btn-primary"
            onClick={() => reviewMutation.mutate()}
            disabled={reviewMutation.isPending || !reviewForm.rendezVousId}
            style={{
              opacity: reviewMutation.isPending || !reviewForm.rendezVousId ? 0.6 : 1,
              cursor: reviewMutation.isPending || !reviewForm.rendezVousId ? "not-allowed" : "pointer",
            }}
          >
            {reviewMutation.isPending ? "Envoi en cours..." : "Envoyer mon avis"}
          </button>
        </div>
      </div>
    </div>
  );
}

function SettingsTab() {
  return (
    <div style={{ width: "100%" }}>
      <div className="card" style={{ padding: 22 }}>
        <h3 style={{ fontWeight: 700, fontSize: 15, marginBottom: 18, color: "#6366f1" }}>Paramètres</h3>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ paddingBottom: 16, borderBottom: "1px solid rgba(99,102,241,0.1)" }}>
            <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 6, color: "#1e1b4b" }}>Notifications</div>
            <div style={{ fontSize: 12, color: "#6b7280", marginBottom: 12 }}>Recevoir des notifications pour les confirmations de rendez-vous</div>
            <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer" }}>
              <input type="checkbox" defaultChecked style={{ cursor: "pointer" }} />
              <span style={{ fontSize: 12, color: "#6b7280" }}>Activer les notifications</span>
            </label>
          </div>

          <div style={{ paddingBottom: 16, borderBottom: "1px solid rgba(99,102,241,0.1)" }}>
            <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 6, color: "#1e1b4b" }}>Confidentialité</div>
            <div style={{ fontSize: 12, color: "#6b7280", marginBottom: 12 }}>Contrôler qui peut voir votre profil</div>
            <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer" }}>
              <input type="checkbox" defaultChecked style={{ cursor: "pointer" }} />
              <span style={{ fontSize: 12, color: "#6b7280" }}>Profil visible publiquement</span>
            </label>
          </div>

          <div>
            <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 12, color: "#ef4444" }}>Zone de danger</div>
            <button
              style={{
                padding: "10px 20px",
                borderRadius: 12,
                border: "1.5px solid #ef4444",
                background: "transparent",
                color: "#ef4444",
                fontWeight: 600,
                fontSize: 14,
                cursor: "pointer",
              }}
            >
              Supprimer mon compte
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
